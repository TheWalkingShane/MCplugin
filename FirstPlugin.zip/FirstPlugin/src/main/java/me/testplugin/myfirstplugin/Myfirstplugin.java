package me.testplugin.myfirstplugin;

import org.bukkit.plugin.java.JavaPlugin;

public final class Myfirstplugin extends JavaPlugin {

    @Override
    public void onEnable() {
        // Plugin startup logic
        System.out.println("plugin is on!");

    }

    @Override
    public void onDisable() {
        // Plugin shutdown logic
        System.out.println("plugin is offh!");
    }
}
